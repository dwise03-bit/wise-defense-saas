# Wise Touch Prompt Shop — Standalone Service

Self-contained React/Vite app. No database, Redis, or .env required. Pure client-side prompt builder with localStorage-backed favorites.

## Deploy on the VPS (wise-defense-saas stack)

1. Upload this whole `wisetouch/` folder to:
   ```
   /home/ubuntu/wise-defense-saas/wisetouch
   ```
   e.g. via scp:
   ```bash
   scp -r wisetouch ubuntu@<vps-ip>:/home/ubuntu/wise-defense-saas/
   ```

2. Edit `/home/ubuntu/wise-defense-saas/docker-compose.yml` and add the block from `docker-compose.snippet.yml` under `services:`, next to `dashboard-v3`.

3. Build and start it:
   ```bash
   cd /home/ubuntu/wise-defense-saas
   docker compose up -d --build wisetouch
   ```

4. Verify:
   ```bash
   docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Ports}}"
   curl -I http://localhost:3003
   ```

5. Reachable at `http://<vps-ip>:3003`, same pattern as dashboard-v2 (3001) and dashboard-v3 (3002).

## Notes

- Port 3003 is free on this VPS as of the last check (3000–3002 in use by api/dashboard-v2/dashboard-v3, 5432/6379 by db/redis).
- No Traefik labels needed — this stack's Traefik has no HTTPS entrypoint configured and isn't used for routing by any current service; this follows the same direct-port pattern as the rest.
- Favorites persist via browser localStorage only — per-device, no sync across machines.
- To update content later (e.g. add new systems/subsystems to `src/App.jsx`):
  ```bash
  docker compose up -d --build wisetouch
  ```
- If you later get a domain and want to move this (or the whole stack) behind Traefik with HTTPS, that's a separate, slightly bigger change — flag it and it can be set up properly rather than bolted on.
